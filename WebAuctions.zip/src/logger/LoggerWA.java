package logger;

import java.util.logging.Logger;

public class LoggerWA {
	public static final Logger LOGGER = Logger.getLogger(LoggerWA.class.getName());
}
